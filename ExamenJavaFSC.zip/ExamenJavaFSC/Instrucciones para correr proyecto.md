1\. Instalar python para correr el front (Esto es para correr el front en un servidor con un puerto con el que se comunicara con el back end)

2\. Si el proyecto front se abre desde el visual studio code abrir una terminal y ejecutar el comando **python -m http.server 5500.**

3\. El back corre con **java 17** (No mencionaron una versión en especifico)

4\. Correr el back

5\. Usuario y contraseña para ingresar al aplicativo usuario = **admin** , contraseña = **admin123**

6\. El archivo txt donde se guardan y se obtienen los usuarios esta en **"examenSpring\\\\src\\\\main\\\\resources\\\\datos"**

6\. El proyecto corre corectamente tanto en Apache Netbeans como en Intellij DEA

Nombre del repositorio:
https://github.com/FSAMAYOA23/Crud-Usuarios-Spring.git


Ingeniero Francisco Samayoa Carmona