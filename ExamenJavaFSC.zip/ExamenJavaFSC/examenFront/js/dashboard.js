let tabla;

function cargarUsuarios(tipoFiltro = '') {
  $.ajax({
    url: 'http://localhost:8080/api/obtenerUsuarios',
    method: 'GET',
    success: function(data) {
      const filtrados = tipoFiltro ? data.filter(u => u.tipoUsuario === tipoFiltro) : data;

      if (tabla) {
        tabla.clear().rows.add(filtrados).draw();
      } else {
        tabla = $('#tablaUsuarios').DataTable({
          data: filtrados,
          columns: [
            { data: 'id' },
            { data: 'clave' },
            { data: 'tipo' },
            { data: 'nombre' },
            { data: 'userName' },
            { data: 'apellidoPaterno' },
            { data: 'apellidoMaterno' },
            //{ data: 'password' },
            { data: 'tipoUsuario' },
            {
                data: 'fechaInicioSesion',
                render: function(data) {
                    const fecha = new Date(data);
                    return fecha.toLocaleDateString('es-MX', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                    });
                }
            },
            {
                data: 'fechaFinSesion',
                render: function(data) {
                    const fecha = new Date(data);
                    return fecha.toLocaleDateString('es-MX', {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                    });
                }
            },
            { data: 'tiempoEnLinea' },
            { data: 'estatus' },
            {
                data: null,
                orderable: false,
                searchable: false,
                render: function(data, type, row) {
                    return `
                    <div class="d-flex justify-content-center gap-2">
                        <button class="btn btn-sm btn-outline-primary editar" data-id="${row.id}" title="Editar">
                        <i class="bi bi-pencil-square"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger eliminar" data-id="${row.id}" title="Eliminar">
                        <i class="bi bi-trash"></i>
                        </button>
                    </div>
                    `;
                }
            }
          ]
        });
      }
    }
  });
}

function eliminarUsuario(id) {
  if (!confirm('¿Estás seguro de que deseas eliminar este usuario?')) return;

  $.ajax({
    url: `http://localhost:8080/api/eliminarUsuario/${id}`,
    method: 'DELETE',
    success: function() {
      alert('Usuario eliminado correctamente');
      const tipo = $('#filtroTipo').val();
      cargarUsuarios(tipo);
    },
    error: function() {
      alert('Error al eliminar el usuario');
    }
  });
}

$(document).ready(function() {
    if ($.fn.DataTable) {
        cargarUsuarios();

        $('#filtroTipo').on('change', function() {
            const tipo = $(this).val();
            cargarUsuarios(tipo);
        });

        $('#btnRefrescar').on('click', function() {
            const tipo = $('#filtroTipo').val();
            cargarUsuarios(tipo);
        });

        $('#tablaUsuarios').on('click', '.editar', function() {
            const id = $(this).data('id');
            window.location.href = `editUser.html?id=${id}`;
        });

        $('#tablaUsuarios').on('click', '.eliminar', function() {
            const id = $(this).data('id');
            eliminarUsuario(id);
        });
    } else {
        console.error('DataTables no está disponible');
    }
});
