document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("loginForm");
  const mensaje = document.getElementById("errorMsg");

  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const usuario = document.getElementById("usuario").value;
    const password = document.getElementById("password").value;

    try {
      const response = await fetch("http://localhost:8080/api/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ usuario, password })
      });

      const texto = await response.text();

      mensaje.style.display = "block";

      if (response.ok) {
        mensaje.textContent = "✅ Inicio de sesión exitoso";
        mensaje.classList.remove("text-danger");
        mensaje.classList.add("text-success");

        // ⏳ Espera breve antes de redirigir
        setTimeout(() => {
          window.location.href = "dashboard.html";
        }, 1000); // 1 segundo para mostrar el mensaje
      } else {
        mensaje.textContent = "❌ Credenciales inválidas";
        mensaje.classList.remove("text-success");
        mensaje.classList.add("text-danger");
      }
    } catch (error) {
      mensaje.textContent = "⚠️ Error de conexión con el servidor";
      mensaje.classList.remove("text-success");
      mensaje.classList.add("text-warning");
      mensaje.style.display = "block";
      console.error(error);
    }
  });
});