document.getElementById('formUsuario').addEventListener('submit', function(e) {
    e.preventDefault(); // Evita el envío tradicional del formulario

    // Captura los valores del formulario
    const usuario = {
        id: document.getElementById('id').value,
        clave: document.getElementById('clave').value,
        tipo: document.getElementById('tipo').value,
        nombre: document.getElementById('nombre').value,
        userName: document.getElementById('userName').value,
        apellidoPaterno: document.getElementById('apellidoPaterno').value,
        apellidoMaterno: document.getElementById('apellidoMaterno').value,
        password: document.getElementById('password').value,
        tipoUsuario: document.getElementById('tipoUsuario').value,
        fechaInicioSesion: formatearFecha(document.getElementById('fechaInicioSesion').value),
        fechaFinSesion: formatearFecha(document.getElementById('fechaFinSesion').value),
        estatus: document.getElementById('estatus').value
    };

    fetch('http://localhost:8080/api/agregarUsuario', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json'
    },
    body: JSON.stringify(usuario)
    })
    .then(async response => {
    if (!response.ok) {
        throw new Error('Error al guardar el usuario');
    }

    const data = await response.json();

    // Verifica si el backend indica éxito
    if (data.exito) {
        // Espera 1 segundo antes de redirigir
        setTimeout(() => {
        window.location.href = 'dashboard.html';
        }, 1000);
    } else {
        throw new Error('La API respondió sin éxito');
    }
    })
    .catch(error => {
    console.error('Error:', error);
    alert('Hubo un problema al guardar el usuario');
    });

});

function formatearFecha(fechaInput) {
  if (!fechaInput) return null;
  const fecha = new Date(fechaInput);
  const yyyy = fecha.getFullYear();
  const mm = String(fecha.getMonth() + 1).padStart(2, '0');
  const dd = String(fecha.getDate()).padStart(2, '0');
  const hh = String(fecha.getHours()).padStart(2, '0');
  const min = String(fecha.getMinutes()).padStart(2, '0');
  const ss = '00'; // segundos fijos
  return `${yyyy}-${mm}-${dd} ${hh}:${min}:${ss}`;
}