// Extraer el ID desde la URL
const params = new URLSearchParams(window.location.search);
const idUsuario = params.get('id');

// Función para convertir fecha al formato datetime-local
function convertirFecha(fechaStr) {
  const fecha = new Date(fechaStr);
  const yyyy = fecha.getFullYear();
  const mm = String(fecha.getMonth() + 1).padStart(2, '0');
  const dd = String(fecha.getDate()).padStart(2, '0');
  const hh = String(fecha.getHours()).padStart(2, '0');
  const min = String(fecha.getMinutes()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}T${hh}:${min}`;
}

// Obtener datos del usuario
fetch(`http://localhost:8080/api/findByIdUser/${idUsuario}`)
  .then(response => response.json())
  .then(data => {
    $('#id').val(data.id);
    $('#clave').val(data.clave);
    $('#tipo').val(data.tipo);
    $('#nombre').val(data.nombre);
    $('#userName').val(data.userName);
    $('#password').val(data.password);
    $('#apellidoPaterno').val(data.apellidoPaterno);
    $('#apellidoMaterno').val(data.apellidoMaterno);
    $('#tipoUsuario').val(data.tipoUsuario);
    $('#fechaInicioSesion').val(convertirFecha(data.fechaInicioSesion));
    $('#fechaFinSesion').val(convertirFecha(data.fechaFinSesion));
    $('#estatus').val(data.estatus);
  })
  .catch(error => {
    console.error('Error al obtener usuario:', error);
    alert('No se pudo cargar el usuario');
  });

// Enviar actualización
$('#formEditarUsuario').on('submit', function(e) {
  e.preventDefault();

  const usuarioActualizado = {
    clave: $('#clave').val(),
    tipo: $('#tipo').val(),
    nombre: $('#nombre').val(),
    userName: $('#userName').val(),
    password: $('#password').val(),
    apellidoPaterno: $('#apellidoPaterno').val(),
    apellidoMaterno: $('#apellidoMaterno').val(),
    tipoUsuario: $('#tipoUsuario').val(),
    fechaInicioSesion: $('#fechaInicioSesion').val().replace('T', ' ') + ':00',
    fechaFinSesion: $('#fechaFinSesion').val().replace('T', ' ') + ':00',
    estatus: $('#estatus').val()
  };

  fetch(`http://localhost:8080/api/actualizarUsuario/${idUsuario}`, {
    method: 'PUT',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(usuarioActualizado)
  })
  .then(response => response.json())
  .then(data => {
    if (data.exito) {
      setTimeout(() => {
        window.location.href = 'dashboard.html';
      }, 1000);
    } else {
      throw new Error(data.mensaje);
    }
  })
  .catch(error => {
    console.error('Error al actualizar usuario:', error);
    alert('Hubo un problema al actualizar el usuario');
  });
});
