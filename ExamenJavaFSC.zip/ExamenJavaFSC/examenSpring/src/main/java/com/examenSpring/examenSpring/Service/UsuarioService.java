package com.examenSpring.examenSpring.Service;

import com.examenSpring.examenSpring.Model.Usuario;
import com.examenSpring.examenSpring.Repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;

    // Usuario hardcodeado
    private final String usuarioHardcoded = "admin";
    private final String passwordHardcoded = "admin123";

    public boolean validarCredenciales(String usuario, String password) {
        return usuarioHardcoded.equals(usuario) && passwordHardcoded.equals(password);
    }

    public Usuario buscarPorId(int id) {
        return usuarioRepository.buscarUsuarioPorId(id);
    }

    public List<Usuario> listaUsuarios() {
        return usuarioRepository.obtenerUsuarios();
    }

    public void agregarUsuario(Usuario usuario) {
        usuarioRepository.guardarUsuario(usuario);
    }

    public Usuario actualizarUsuario(int id, Usuario nuevosDatos) {
        usuarioRepository.actualizarUsuario(id, nuevosDatos);
        return nuevosDatos;
    }

    public boolean eliminarUsuario(int id) {
        return usuarioRepository.eliminarUsuario(id);
    }
}
