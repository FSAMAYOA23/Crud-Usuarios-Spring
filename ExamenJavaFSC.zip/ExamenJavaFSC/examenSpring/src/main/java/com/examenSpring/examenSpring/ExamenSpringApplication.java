package com.examenSpring.examenSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenSpringApplication.class, args);
	}

}
