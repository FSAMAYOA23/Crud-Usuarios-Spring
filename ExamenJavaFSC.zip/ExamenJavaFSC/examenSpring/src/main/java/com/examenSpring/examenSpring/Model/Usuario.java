package com.examenSpring.examenSpring.Model;

import lombok.Data;

@Data
public class Usuario {
    private int id;
    private String clave;
    private String tipo;
    private String nombre;
    private String userName;
    private String apellidoPaterno;
    private String apellidoMaterno;
    private String password;
    private String tipoUsuario;
    private String fechaInicioSesion;
    private String fechaFinSesion;
    private String tiempoEnLinea;
    private String estatus;

    public Usuario(int id, String clave, String tipo, String nombre, String apellidoPaterno, String username, String apellidoMaterno, String password, String tipoUsuario, String fechaInicioSesion, String fechaFinSesion, String tiempoEnLinea, String estatus) {
        this.id = id;
        this.clave = clave;
        this.tipo = tipo;
        this.nombre = nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.userName = username;
        this.apellidoMaterno = apellidoMaterno;
        this.password = password;
        this.tipoUsuario = tipoUsuario;
        this.fechaInicioSesion = fechaInicioSesion;
        this.fechaFinSesion = fechaFinSesion;
        this.tiempoEnLinea = tiempoEnLinea;
        this.estatus = estatus;
    }

    public Usuario() {

    }

    public String toLineaTxt() {
        return String.join("|",
                String.valueOf(id), clave, tipo, nombre, apellidoPaterno,
                userName, apellidoMaterno, password, tipoUsuario,
                fechaInicioSesion, fechaFinSesion, estatus
        );
    }
}

