package com.examenSpring.examenSpring.Controller;

import com.examenSpring.examenSpring.Model.Usuario;
import com.examenSpring.examenSpring.RespuestaApi;
import com.examenSpring.examenSpring.Service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    @PostMapping("/login")
    public ResponseEntity<RespuestaApi> login(@RequestBody Map<String, String> credenciales) {
        String usuario = credenciales.get("usuario");
        String password = credenciales.get("password");

        boolean valido = usuarioService.validarCredenciales(usuario, password);

        if (valido) {
            return ResponseEntity.ok(new RespuestaApi(true, "Inicio de sesión exitoso"));
        } else {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body(new RespuestaApi(false, "Credenciales inválidas"));
        }
    }

    @GetMapping("/findByIdUser/{id}")
    public Usuario obtenerUsuarioPorId(@PathVariable int id) {
        return usuarioService.buscarPorId(id);
    }

    @GetMapping("/obtenerUsuarios")
    public List<Usuario> obtenerUsuarios() {
        return usuarioService.listaUsuarios();
    }

    @PostMapping("/agregarUsuario")
    public ResponseEntity<RespuestaApi> agregarUsuario(@RequestBody Usuario usuario) {
        try {
            usuarioService.agregarUsuario(usuario);
            RespuestaApi respuesta = new RespuestaApi(true, "Usuario agregado correctamente");
            return ResponseEntity.ok(respuesta);
        } catch (Exception e) {
            RespuestaApi respuesta = new RespuestaApi(false, "Error al guardar el usuario");
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(respuesta);
        }
    }

    @PutMapping("/actualizarUsuario/{id}")
    public ResponseEntity<RespuestaApi> actualizarUsuario(@PathVariable int id, @RequestBody Usuario nuevosDatos) {
        try {
            Usuario actualizado = usuarioService.actualizarUsuario(id, nuevosDatos);

            if (actualizado != null) {
                return ResponseEntity.ok(new RespuestaApi(true, "Usuario actualizado correctamente"));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new RespuestaApi(false, "Usuario no encontrado"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new RespuestaApi(false, "Error al actualizar el usuario"));
        }
    }

    @DeleteMapping("/eliminarUsuario/{id}")
    public ResponseEntity<RespuestaApi> eliminarUsuario(@PathVariable int id) {
        try {
            boolean eliminado = usuarioService.eliminarUsuario(id);

            if (eliminado) {
                return ResponseEntity.ok(new RespuestaApi(true, "Usuario con ID " + id + " eliminado correctamente"));
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(new RespuestaApi(false, "Usuario con ID " + id + " no encontrado o error al eliminar"));
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(new RespuestaApi(false, "Error interno al eliminar el usuario"));
        }
    }

}
