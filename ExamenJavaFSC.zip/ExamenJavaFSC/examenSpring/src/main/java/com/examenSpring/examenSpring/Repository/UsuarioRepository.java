package com.examenSpring.examenSpring.Repository;

import com.examenSpring.examenSpring.Model.Usuario;
import org.springframework.stereotype.Repository;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;

@Repository
public class UsuarioRepository {

    private final Path archivo = Paths.get("src/main/resources/datos/usuarios.txt");

    public void guardarUsuario(Usuario usuario) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivo.toFile(), true))) {
            writer.write(usuario.toLineaTxt()); // sin \n aquí
            writer.newLine(); // agrega un solo salto de línea
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Usuario buscarUsuarioPorId(int idBuscado) {
        try (Stream<String> lineas = Files.lines(archivo)) {
            return lineas
                    .map(linea -> {
                        String[] partes = linea.split("\\|");
                        if (partes.length < 12) return null;

                        int id = Integer.parseInt(partes[0]);
                        if (id != idBuscado) return null;

                        var inicioSesion = partes[9];
                        var finSesion = partes[10];

                        Usuario usuario = new Usuario();
                        usuario.setId(id);
                        usuario.setClave(partes[1]);
                        usuario.setTipo(partes[2]);
                        usuario.setNombre(partes[3]);
                        usuario.setUserName(partes[4]);
                        usuario.setApellidoPaterno(partes[5]);
                        usuario.setApellidoMaterno(partes[6]);
                        usuario.setPassword(partes[7]);
                        usuario.setTipoUsuario(partes[8]);
                        usuario.setFechaInicioSesion(inicioSesion);
                        usuario.setFechaFinSesion(finSesion);
                        usuario.setTiempoEnLinea(calcularTiempoEnLinea(inicioSesion, finSesion));
                        usuario.setEstatus(partes[11]);

                        return usuario;
                    })
                    .filter(Objects::nonNull)
                    .findFirst()
                    .orElse(null);
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<Usuario> obtenerUsuarios() {
        List<Usuario> usuarios = new ArrayList<>();
        try (Stream<String> lineas = Files.lines(archivo)) {
            lineas.forEach(linea -> {
                String[] partes = linea.split("\\|");
                for(int i = 0; i < partes.length; i++) {
                    System.out.println("partes[" + i + "]: " + partes[i]);
                }
                var inicioSesion = partes[9];
                var finSesion = partes[10];

                Usuario usuario = new Usuario();
                usuario.setId(Integer.parseInt(partes[0]));
                usuario.setClave(partes[1]);
                usuario.setTipo(partes[2]);
                usuario.setNombre(partes[3]);
                usuario.setUserName(partes[4]);
                usuario.setApellidoPaterno(partes[5]);
                usuario.setApellidoMaterno(partes[6]);
                usuario.setPassword(partes[7]);
                usuario.setTipoUsuario(partes[8]);
                usuario.setFechaInicioSesion(inicioSesion);
                usuario.setFechaFinSesion(finSesion);
                usuario.setTiempoEnLinea(calcularTiempoEnLinea(inicioSesion, finSesion));
                usuario.setEstatus(partes[11]);

                usuarios.add(usuario);
            });
        } catch (IOException e) {
            e.printStackTrace();
        }
        return usuarios;
    }

    public void actualizarUsuario(int id, Usuario nuevosDatos) {
        List<Usuario> usuarios = obtenerUsuarios();
        boolean actualizado = false;

        for (int i = 0; i < usuarios.size(); i++) {
            Usuario original = usuarios.get(i);
            if (original.getId() == id) {
                nuevosDatos.setId(id);

                String nuevoTiempo = calcularTiempoEnLinea(nuevosDatos.getFechaInicioSesion(), nuevosDatos.getFechaFinSesion());
                nuevosDatos.setTiempoEnLinea(nuevoTiempo);

                usuarios.set(i, nuevosDatos);
                actualizado = true;
                break;
            }
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivo.toFile()))) {
            if (!actualizado) {
                throw new RuntimeException("Usuario con ID " + id + " no encontrado.");
            }

            for (Usuario u : usuarios) {
                writer.write(u.toLineaTxt());
                writer.newLine();
            }

        } catch (IOException | RuntimeException e) {
            System.err.println("Error al actualizar usuario: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public boolean eliminarUsuario(int id) {
        List<Usuario> usuarios = obtenerUsuarios();
        boolean eliminado = usuarios.removeIf(u -> u.getId() == id);

        if (!eliminado) {
            System.err.println("Usuario con ID " + id + " no encontrado.");
            return false;
        }

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(archivo.toFile()))) {
            for (Usuario u : usuarios) {
                writer.write(u.toLineaTxt());
                writer.newLine();
            }
            return true;
        } catch (IOException e) {
            System.err.println("Error al escribir el archivo: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    private String calcularTiempoEnLinea(String inicio, String fin) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

        LocalDateTime fechaInicio = LocalDateTime.parse(inicio, formatter);
        LocalDateTime fechaFin = LocalDateTime.parse(fin, formatter);

        Duration duracion = Duration.between(fechaInicio, fechaFin);
        long horas = duracion.toHours();
        long minutos = duracion.toMinutes() % 60;

        return horas + "h " + minutos + "m";
    }

}